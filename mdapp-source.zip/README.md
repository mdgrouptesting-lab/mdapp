# MD Group — Website + App

Next.js 15 (App Router) · TypeScript · Tailwind CSS · Firebase (Auth, Firestore, Storage) · Razorpay

Construction · Planning · Soil Testing · Land Survey · Material Testing · G+1 House Construction · Interior Design

## What's inside

| Area | Features |
|---|---|
| **Website** | Animated hero, services (each with its own page), about, membership plans, blog, contact page with enquiry form (phone, address, requirement), floating Call/WhatsApp buttons |
| **App (PWA)** | Installable on Android/iPhone ("Add to Home screen"), MD Group logo icons, bottom navigation on mobile |
| **Client** | Register → pay **₹50 once (lifetime)** → report a problem: choose the problem type + upload photos → company gets it (Admin panel + optional email) and calls → track status |
| **Worker** | Register with type of work (carpenter, mason, plumber…) → pay **₹100/year** (renew online) → upload ID proof + work photos for verification → get jobs assigned → upload completion photos for the company to verify. Customers pay the company, never the worker. |
| **Admin / Owner** | Dashboard stats · Enquiries (call/WhatsApp, status) · Service requests (assign verified workers, verify completed work) · Clients · Workers (approve/reject verification, activate membership for cash payments) · Payments · Blog posts (write/publish with cover image) · Work types · Admins & roles |

---

## 1. Install

You need **Node.js 20+** (https://nodejs.org).

```bash
cd mdapp
npm install
```

## 2. Create a Firebase project

1. Go to https://console.firebase.google.com → **Add project**.
2. **Build → Authentication → Get started → Email/Password → Enable**.
3. **Build → Firestore Database → Create database** (production mode, region `asia-south1` Mumbai).
4. **Build → Storage → Get started** (needs the Blaze pay‑as‑you‑go plan on new projects; small usage is within the free tier).
5. **Project settings → General → Your apps → Web app (</>)** → copy the config values.
6. **Project settings → Service accounts → Generate new private key** → a JSON file downloads (keep it secret).

## 3. Environment variables

Copy `.env.example` to `.env.local` and fill it in:

```bash
copy .env.example .env.local     # Windows
cp .env.example .env.local       # Mac/Linux
```

* `NEXT_PUBLIC_FIREBASE_*` → from step 5.
* `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` → from the JSON file in step 6 (keep the quotes and `\n`).
* `ADMIN_EMAILS` → the owner's email. **Register with this email and you become admin with full access.**
* `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `NEXT_PUBLIC_RAZORPAY_KEY_ID` → https://dashboard.razorpay.com → Settings → API Keys (start with **test** keys).
* `SMTP_*` + `COMPANY_NOTIFY_EMAIL` → optional. Enquiries and problem reports always appear in the Admin panel; if SMTP is filled, an email with the photos is also sent. For Gmail use an **App password** (Google Account → Security → 2‑Step Verification → App passwords).

## 4. Deploy security rules

```bash
npm install -g firebase-tools
firebase login
firebase use --add            # pick your project
firebase deploy --only firestore:rules,storage
```

(Allow Storage to read Firestore when asked. The rules are needed for admin checks.)

## 5. Run

```bash
npm run dev       # http://localhost:3000
```

1. Open `/register/client` and register with the **ADMIN_EMAILS** address → you land in `/admin`.
2. In **Admin → Work Types** click "Load default list" (optional; the site uses defaults until then).
3. Test a client and a worker account in another browser/incognito window.
4. Razorpay test UPI: `success@razorpay`, or test card `4111 1111 1111 1111`, any future date, any CVV.

## 6. Edit company details

All contact details, stats and prices are in **`src/lib/config.ts`** (phone, WhatsApp, email, address, Google Maps embed, social links, ₹50 / ₹100 prices). Services text is in **`src/lib/services.ts`**, work types and problem types in **`src/lib/workTypes.ts`**.

Logo: `public/logo.svg` (icons in `public/icons/` and `src/app/icon.svg`).

## 7. Deploy (Vercel recommended)

1. Push the folder to GitHub.
2. https://vercel.com → **New Project** → import the repo.
3. Add all variables from `.env.local` in **Settings → Environment Variables** (set `NEXT_PUBLIC_SITE_URL` to your domain).
4. Firebase → Authentication → Settings → **Authorized domains** → add your domain.
5. Razorpay → switch to **live** keys after KYC.

## How the flows work

```
Client:  register → pay ₹50 (lifetime) → Report problem (type + photos)
         → saved in Firestore + email to company → Admin calls client
         → Admin assigns a verified worker → worker uploads completion photos
         → Admin verifies → status "completed". Client pays the company only.

Worker:  register (type of work) → pay ₹100 (valid 1 year, renew from dashboard)
         → upload ID + work photos → Admin approves → receives jobs.
```

Security: user roles, membership status and payments are written only by the server (`/api/*` with Firebase Admin) or by admins — the browser can't make itself admin or mark itself as paid. Payment amounts are decided on the server and each Razorpay signature is verified.

## Project structure

```
src/
  app/
    (site)/            public website: home, about, services, membership, blog, contact
    (auth)/            login, register/client, register/worker
    dashboard/         client & worker app screens
    admin/             admin panel
    api/               enquiry, auth/register, requests, payment/create-order, payment/verify
  components/          site, auth, dashboard, admin, ui
  lib/                 config, services, firebase (client/admin), mail, razorpay, types, utils
firestore.rules, storage.rules
```
